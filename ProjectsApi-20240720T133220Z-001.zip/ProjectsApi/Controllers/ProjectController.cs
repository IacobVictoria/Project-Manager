﻿using InternshipAPI.Models;
using InternshipAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace InternshipAPI.Controllers
{
    [Route("api/project")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private readonly IProjectService _projectService;

        public ProjectController(IProjectService projectService)
        {
            _projectService = projectService;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<Project>))]
        public async Task<ActionResult<Project>> GetAll()
        {
            try
            {
                var result = await _projectService.GetAll();

                return Ok(result);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet("by-id")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Project))]
        public async Task<ActionResult<Project>> GetById(string id)
        {
            try
            {
                var result = await _projectService.GetById(id);

                return Ok(result);
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

        [HttpPost("add")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Project))]
        public async Task<ActionResult<Project>> Add([FromBody] AddProjectRequest request)
        {
            try
            {
                var result = await _projectService.AddProject(request);

                return Ok(result);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost("update")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Project))]
        public async Task<ActionResult<Project>> Update([FromBody] UpdateProjectRequest request)
        {
            try
            {
                var result = await _projectService.UpdateProject(request);

                return Ok(result);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpDelete("delete")]
        public async Task<ActionResult> Delete(string id)
        {
            try
            {
                await _projectService.DeleteProject(id);

                return Ok("Project deleted successfully");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
