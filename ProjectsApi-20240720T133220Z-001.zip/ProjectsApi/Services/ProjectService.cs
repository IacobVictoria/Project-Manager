﻿using InternshipAPI.Models;
using Repository;

namespace InternshipAPI.Services
{
    public class ProjectService : IProjectService
    {
        private readonly IMongoRepository<Project> _projectRepository;

        public ProjectService(IMongoRepository<Project> projectRepository)
        {
            _projectRepository = projectRepository;
        }

        public async Task<Project> AddProject(AddProjectRequest request)
        {
            var project = new Project
            {
                Name = request.Name,
                Description = request.Description,
                Technologies = request.Technologies,
            };

           
            await _projectRepository.InsertAsync(project);

            return project;
        }

        public async Task DeleteProject(string id)
        {
           await _projectRepository.DeleteByIdAsync(id);
        }

        public async Task<List<Project>> GetAll()
        {
            var projects = await _projectRepository.FindAsync();

            return projects.OrderBy(l => l.Name).ToList();
        }

        public async Task<Project> GetById(string id)
        {
            var existingProject = await _projectRepository.FindByIdAsync(id) ?? throw new Exception("Could not find project!");

            return existingProject;
        }

        public async Task<Project> UpdateProject(UpdateProjectRequest request)
        {
            var existingProject = await _projectRepository.FindByIdAsync(request.Id) ?? throw new Exception("Could not find project!");

            existingProject.Name = request.Name;
            existingProject.Description = request.Description;
            existingProject.Technologies = request.Technologies;

            await _projectRepository.ReplaceAsync(existingProject);
            return existingProject;
        }
    }
}
