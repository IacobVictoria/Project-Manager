﻿using InternshipAPI.Models;

namespace InternshipAPI.Services
{
    public interface IProjectService
    {
        Task<List<Project>> GetAll();

        Task<Project> GetById(string id);


        Task<Project> AddProject(AddProjectRequest request);


        Task<Project> UpdateProject(UpdateProjectRequest request);

        Task DeleteProject(string id);
    }
}
