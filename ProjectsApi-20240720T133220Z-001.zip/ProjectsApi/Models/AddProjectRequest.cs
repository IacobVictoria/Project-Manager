﻿namespace InternshipAPI.Models
{
    public class AddProjectRequest :  BaseProjectRequest
    {
    }
}
