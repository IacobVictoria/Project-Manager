﻿namespace InternshipAPI.Models
{
    public class UpdateProjectRequest : BaseProjectRequest
    {
        public required string Id { get; set; }
    }
}
