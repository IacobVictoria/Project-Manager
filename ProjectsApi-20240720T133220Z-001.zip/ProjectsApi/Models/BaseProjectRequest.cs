﻿namespace InternshipAPI.Models
{
    public abstract class BaseProjectRequest
    {
        public required string Name { get; set; }

        public required string Description { get; set; }

        public List<string>? Technologies { get; set; }
    }
}
