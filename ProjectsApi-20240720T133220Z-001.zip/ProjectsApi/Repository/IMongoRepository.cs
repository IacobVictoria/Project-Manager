﻿using System.Linq.Expressions;
using System.Runtime.InteropServices;
using MongoDB.Driver;
using Models;

namespace Repository
{
    public interface IMongoRepository<TDocument> where TDocument : BaseDocument
    {
        Task<List<TDocument>> FindAllWithFilterAsync(FilterDefinition<TDocument> filter);

        Task<TDocument> FindByIdAsync(string id);

        TDocument FindOne(Expression<Func<TDocument, bool>> filterExpression);

        TDocument? FindLast();

        List<TDocument> FindWithFilter(Expression<Func<TDocument, bool>> filterExpression);

        List<TDocument> FindAll();

        Task DeleteByIdAsync(string id);

        void DeleteWithFilter(FilterDefinition<TDocument> filter);

        void Clear();

        Task ReplaceAsync(TDocument document);

        Task<TDocument> InsertAsync(TDocument document);

        Task<List<string>> FindDistinctValuesAsync(string field);

        Task<List<TDocument>> FindAsync([Optional] string? searchWord);
    }
}
