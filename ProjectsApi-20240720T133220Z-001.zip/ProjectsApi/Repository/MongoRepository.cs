﻿using System.Linq.Expressions;
using System.Runtime.InteropServices;
using Models;
using MongoDB.Bson;
using MongoDB.Driver;
using Repository;

namespace InternshipAPI.Repository
{
    public class MongoRepository<TDocument> : IMongoRepository<TDocument> where TDocument : BaseDocument
    {
        private readonly IMongoCollection<TDocument> _collection;

        public MongoRepository(IMongoDbSettings settings)
        {
            var database = new MongoClient(settings.ConnectionString).GetDatabase(settings.DatabaseName);
            _collection = database.GetCollection<TDocument>(MongoRepository<TDocument>.GetCollectionName(typeof(TDocument)));
        }

        public TDocument FindOne(Expression<Func<TDocument, bool>> filterExpression)
        {
            return _collection.Find(filterExpression).FirstOrDefault();
        }

        public TDocument? FindLast()
        {
            var queryableCollection = _collection.AsQueryable();
            return queryableCollection.Any() ? _collection.AsQueryable().OrderByDescending(c => c.CreatedAt).First() : null;
        }

        public List<TDocument> FindWithFilter(Expression<Func<TDocument, bool>> filterExpression)
        {
            return _collection.Find(filterExpression).ToList();
        }

        public List<TDocument> FindAll()
        {
            return _collection.Find(new BsonDocument()).ToList();
        }

        public Task<List<TDocument>> FindAllWithFilterAsync(FilterDefinition<TDocument> filter)
        {
            return _collection.Find(filter).ToListAsync();
        }

        public Task<TDocument> FindByIdAsync(string id)
        {
            return Task.Run(() =>
            {
                var filter = Builders<TDocument>.Filter.Eq(doc => doc.Id, id);
                return _collection.Find(filter).SingleOrDefaultAsync();
            });
        }

        public Task DeleteByIdAsync(string id)
        {
            var filter = Builders<TDocument>.Filter.Eq(doc => doc.Id, id);
            return _collection.DeleteOneAsync(filter);
        }

        public Task ReplaceAsync(TDocument document)
        {
            var filter = Builders<TDocument>.Filter.Eq(doc => doc.Id, document.Id);

            document.ModifiedAt = DateTime.UtcNow;

            return _collection.ReplaceOneAsync(filter, document);
        }

        public async Task<TDocument> InsertAsync(TDocument document)
        {
            if (document.CreatedAt == DateTime.MinValue)
            {
                document.CreatedAt = DateTime.UtcNow;
            }

            await _collection.InsertOneAsync(document);

            return document;
        }

        public async Task<List<string>> FindDistinctValuesAsync(string field)
        {
            var filter = new BsonDocument();
            var cursor = await _collection.DistinctAsync<string>(field, filter);
            var distinctValues = cursor.ToEnumerable().Where(value => !string.IsNullOrEmpty(value));

            return distinctValues.ToList();
        }

        public Task<List<TDocument>> FindAsync([Optional] string? searchWord)
        {
            if (searchWord != null)
            {
                var options = new TextSearchOptions() { CaseSensitive = false };
                var filter = Builders<TDocument>.Filter.Text("\"" + searchWord + "\"", options);

                return _collection.Find(filter).ToListAsync();
            }
            else
            {
                return _collection.Find(FilterDefinition<TDocument>.Empty).ToListAsync();
            }
        }

        public void Clear()
        {
            var filter = new BsonDocument();
            _collection.DeleteMany(filter);
        }

        public void DeleteWithFilter(FilterDefinition<TDocument> filter)
        {
            _collection.DeleteMany(filter);
        }

        private static string GetCollectionName(Type documentType)
        {
            return ((BsonCollectionAttribute)documentType.GetCustomAttributes(
                    typeof(BsonCollectionAttribute),
                    true)
                .FirstOrDefault())?.CollectionName;
        }
    }
}
