import {
	ActivatedRouteSnapshot,
	ResolveFn,
	RouterStateSnapshot,
} from '@angular/router';
import { TaskService } from '../_services/task.service';
import { TaskForm } from '../_interfaces/task-form.interface';
import { inject } from '@angular/core';
import { Task } from '../_interfaces/task.interface';

export const TaskResolver: ResolveFn<Task | null> = (
	route: ActivatedRouteSnapshot,
	state: RouterStateSnapshot
) => {
	const taskService = inject(TaskService);
	const id = route.paramMap.get('id');

	if (!id) {
		return null;
	}

	return taskService.getTaskByID(id);
};
