import { Component } from '@angular/core';
import { TaskComponent } from './active-tasks/task/task.component';
import { MatAccordion } from '@angular/material/expansion';
import { MatButtonModule } from '@angular/material/button';
import { UserSummary } from '../_interfaces/user-summary.interface';
import { CommonModule } from '@angular/common';
import { ActiveTasksComponent } from './active-tasks/active-tasks.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserComponent } from './user-list/user/user.component';

@Component({
	selector: 'app-user-tasks-page',
	standalone: true,
	imports: [
		TaskComponent,
		MatAccordion,
		MatButtonModule,
		UserListComponent,
		UserComponent,
		CommonModule,
		ActiveTasksComponent,
	],
	templateUrl: './user-tasks-page.component.html',
	styleUrls: ['./user-tasks-page.component.scss'],
})
export class UserTasksPageComponent {
	selectedUser: UserSummary | null = null;

	onUserSelected(user: UserSummary | null): void {
		this.selectedUser = user;
	}
}
