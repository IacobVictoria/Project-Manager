import {
	Component,
	EventEmitter,
	inject,
	OnDestroy,
	OnInit,
	Output,
} from '@angular/core';
import { Subscription } from 'rxjs';
import { UserComponent } from './user/user.component';
import { ListContainerComponent } from '../../_shared/list-container/list-container.component';
import { UserSummary } from '../../_interfaces/user-summary.interface';
import { UserService } from '../../_services/user.service';
import { RefreshService } from '../../_services/refresh.service';
@Component({
	selector: 'app-user-list',
	standalone: true,
	imports: [UserComponent, ListContainerComponent],
	templateUrl: './user-list.component.html',
	styleUrls: ['./user-list.component.scss'],
})
export class UserListComponent implements OnDestroy, OnInit {
	users!: UserSummary[];
	selectedUser: UserSummary | null = null;
	lastClickedUserId: string | null = null;
	private userService: UserService = inject(UserService);
	private refreshService: RefreshService = inject(RefreshService);
	private subscription = new Subscription();

	@Output() userSelected = new EventEmitter<UserSummary | null>();

	ngOnInit(): void {
		this.getUsers();
		this.subscription.add(
			this.refreshService.refresh.subscribe(() => {
				this.getUsers();
			})
		);
	}

	ngOnDestroy(): void {
		this.subscription.unsubscribe();
	}

	getUsers(): void {
		this.subscription.add(
			this.userService.getUsers().subscribe((users: UserSummary[]) => {
				this.users = users;
			})
		);
	}

	trackByUserId(_index: number, user: UserSummary): string {
		return user.id;
	}

	onUserClicked(user: UserSummary): void {
		if (this.lastClickedUserId === user.id) {
			this.selectedUser = null;
			this.lastClickedUserId = null;
		} else {
			this.selectedUser = user;
			this.lastClickedUserId = user.id;
		}

		this.userSelected.emit(this.selectedUser);
	}
}
