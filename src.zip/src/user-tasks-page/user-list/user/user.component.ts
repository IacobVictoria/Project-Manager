import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { UserSummary } from '../../../_interfaces/user-summary.interface';
@Component({
	selector: 'app-user',
	standalone: true,
	imports: [CommonModule],
	templateUrl: './user.component.html',
	styleUrl: './user.component.scss',
})
export class UserComponent {
	@Input() user!: UserSummary;
	@Output() userClicked = new EventEmitter<UserSummary>();
	@Input() isActive: boolean = false;
	private router: Router = inject(Router);

	onClick(): void {
		this.userClicked.emit(this.user);
	}

	navigateToDetails(): void {
		this.router.navigate(['/user-details', this.user.id]);
	}
}
