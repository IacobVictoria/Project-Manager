import {
	Component,
	inject,
	Input,
	OnChanges,
	OnDestroy,
	OnInit,
	SimpleChanges,
	viewChild,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatAccordion } from '@angular/material/expansion';
import { TaskService } from '../../_services/task.service';
import { RefreshService } from '../../_services/refresh.service';
import { Subscription } from 'rxjs';
import { TaskComponent } from './task/task.component';
import { TaskSummary } from '../../_interfaces/task-summary.interface';

@Component({
	selector: 'app-active-tasks',
	standalone: true,
	imports: [MatAccordion, MatButtonModule, TaskComponent],
	templateUrl: './active-tasks.component.html',
	styleUrl: './active-tasks.component.scss',
})
export class ActiveTasksComponent implements OnInit, OnChanges, OnDestroy {
	private subscription = new Subscription();
	private taskService: TaskService = inject(TaskService);
	activeTasks: TaskSummary[] = [];
	private refreshService: RefreshService = inject(RefreshService);

	accordion = viewChild.required(MatAccordion);

	@Input({ required: true }) userId!: string;

	ngOnInit(): void {
		this.subscription.add(
			this.refreshService.refresh.subscribe(() => {
				this.taskService.getActiveTasks(this.userId).subscribe();
			})
		);

		this.subscription.add(
			this.taskService.getActiveTasks(this.userId).subscribe()
		);

		this.subscription.add(
			this.taskService.activeTasks$.subscribe((activeTasks) => {
				this.activeTasks = activeTasks;
			})
		);
	}

	ngOnChanges(changes: SimpleChanges): void {
		const userId = changes['userId'].currentValue;

		if (!userId) return;

		this.taskService.getActiveTasks(userId).subscribe();
	}

	ngOnDestroy(): void {
		this.subscription.unsubscribe();
	}

	goToTop(): void {
		const firstTaskElement = document.querySelector('app-task');
		if (!firstTaskElement) {
			return;
		}

		firstTaskElement.scrollIntoView({ behavior: 'smooth' });
	}
}
