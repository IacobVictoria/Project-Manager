import { Component, inject, Input, OnInit } from '@angular/core';
import { Task } from '../../../_interfaces/task.interface';
import { TaskService } from '../../../_services/task.service';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatButtonModule } from '@angular/material/button';
import { ConfirmDialogService } from '../../../_services/confirm-dialog.service';
import { TaskSummary } from '../../../_interfaces/task-summary.interface';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
	selector: 'app-task',
	standalone: true,
	imports: [MatExpansionModule, MatButtonModule, DatePipe],
	templateUrl: './task.component.html',
	styleUrl: './task.component.scss',
})
export class TaskComponent implements OnInit {
	private router: Router = inject(Router);
	private taskService: TaskService = inject(TaskService);
	private confirmDialogService: ConfirmDialogService = inject(ConfirmDialogService);

	@Input({ required: true }) taskSummary!: TaskSummary;
	protected task?: Task;

	ngOnInit(): void {
		this.taskService.getTaskByID(this.taskSummary.id!).subscribe((task) => {
			this.task = task;
		});
	}

	editTask(): void {
		this.router.navigate([`edit-task/${this.taskSummary.id}`]);
	}

	deleteTask(): void {
		this.confirmDialogService
			.confirmDialog({
				title: 'Delete task',
				message: 'Are you sure you want to delete this task ?',
				confirmText: 'Yes',
				cancelText: 'No',
			})
			.subscribe((response) => {
				if (!response) return;

				this.taskService.deleteTask(this.taskSummary.id!).subscribe();
			});
	}
}
