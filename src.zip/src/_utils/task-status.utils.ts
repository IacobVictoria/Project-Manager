import { TaskStatus } from '../_enums/task-status.enum';
import { SelectItem } from '../_interfaces/select-item.interface';

export class TaskStatusUtils {
	static mapTaskStatusToSelectOption(): SelectItem[] {
		return Object.keys(TaskStatus)
			.filter((key) => isNaN(Number(key)))
			.map((key) => ({
				label: key,
				value: TaskStatus[key as keyof typeof TaskStatus],
			}));
	}
}
