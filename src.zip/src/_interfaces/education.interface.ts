export interface Education {
    institution: string;
    section: string;
    level: string;
    startDate: Date;
    dueDate: Date;
    endDate: Date;
    description: string;
  }