import { TaskStatus } from '../_enums/task-status.enum';

export interface AddTaskRequest {
	status: TaskStatus;
	description: string;
	completedAt?: Date | null;
	title: string;
	userId: string;
	startedAt: Date;
	dueDate: Date;
}
