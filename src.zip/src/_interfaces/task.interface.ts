import { TaskStatus } from "../_enums/task-status.enum";

export interface Task {
    id: string;
    userId: string;
    title: string;
    description: string;
    status: TaskStatus;
    dueDate: Date;
    startedAt: Date;
    completedAt: Date | null;
}