export interface ShowLeavePageConfirmationDialog {
	showLeavePageConfirmationDialog: () => boolean;
}
