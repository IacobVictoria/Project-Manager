import { TaskStatus } from "../_enums/task-status.enum";

export interface UpdateTaskRequest {
    status: TaskStatus;
    description: string;
    completedAt?: Date | null;
    id: string;
}