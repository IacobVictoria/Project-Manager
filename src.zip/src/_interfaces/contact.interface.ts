export interface Contact {
    email: string;
    phoneNumber: string;
    linkedin: string;
  }