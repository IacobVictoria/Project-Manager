export interface SelectItem {
	label: string;
	value: number;
}
