export interface TaskSummary {
    id: string;
    title: string;
    userId: string;
    dueDate: Date;
}