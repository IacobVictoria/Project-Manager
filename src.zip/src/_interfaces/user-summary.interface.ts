export interface UserSummary {
	id: string;
	firstName: string;
	lastName: string;
	avatar: string;
}
