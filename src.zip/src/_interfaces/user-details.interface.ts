import { Contact } from './contact.interface';
import { Education } from './education.interface';

export interface UserDetails {
	id: string;
	firstName: string;
	lastName: string;
	avatar: string;
	contactDetails?: Contact;
	educationDetails?: Education;
}
