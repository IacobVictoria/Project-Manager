import { FormControl } from "@angular/forms";
import { TaskStatus } from "../_enums/task-status.enum";

export interface TaskForm {
    userId: FormControl<string | null>;
    title: FormControl<string | null>;
    description: FormControl<string | null>;
    status: FormControl<TaskStatus | null>;
    dueDate: FormControl<Date | null>;
    startedAt: FormControl<Date | null>;
    completedAt: FormControl<Date | null>;
}