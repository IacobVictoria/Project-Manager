import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Task } from '../_interfaces/task.interface';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { TASK_URL } from '../_constants/endpoints.constants';
import { AddTaskRequest } from '../_interfaces/add-task-request.interface';
import { UpdateTaskRequest } from '../_interfaces/update-task-request.interface';
import { TaskSummary } from '../_interfaces/task-summary.interface';
import { TaskForm } from '../_interfaces/task-form.interface';

@Injectable({ providedIn: 'root' })
export class TaskService {
	private url = TASK_URL;
	private httpClient = inject(HttpClient);

	private activeTasksSubject$ = new BehaviorSubject<TaskSummary[]>([]);

	public activeTasks$: Observable<TaskSummary[]> =
		this.activeTasksSubject$.asObservable();

	public getTasks(userId: string, status?: number): Observable<Task[]> {
        let queryParams = `userId=${userId}`;
        if (status !== undefined) {
            queryParams += `&status=${status}`;
        }
        return this.httpClient.get<Task[]>(`${this.url}?${queryParams}`);
    }

	public getActiveTasks(userId: string): Observable<TaskSummary[]> {
		return this.httpClient
			.get<TaskSummary[]>(`${this.url}/active?userId=${userId}`)
			.pipe(
				tap((activeTasks) => this.activeTasksSubject$.next(activeTasks))
			);
	}

	public getTaskByID(id: string): Observable<Task> {
		return this.httpClient.get<Task>(`${this.url}/by-id?id=${id}`);
	}

	public editTask(editedTask: UpdateTaskRequest): Observable<UpdateTaskRequest> {
		return this.httpClient.put<UpdateTaskRequest>(`${this.url}/update`, editedTask);
	}

	public deleteTask(id: string): Observable<string> {
		return this.httpClient
			.delete(`${this.url}/delete?id=${id}`, {
				responseType: 'text',
			})
			.pipe(
				tap(() => {
					const currentTasks = this.activeTasksSubject$.getValue();
					const updatedTasks = currentTasks.filter(
						(task) => task.id !== id
					);
					this.activeTasksSubject$.next(updatedTasks);
				})
			);
	}

	public addNewTask(newTask: AddTaskRequest): Observable<AddTaskRequest> {
		return this.httpClient.post<AddTaskRequest>(`${this.url}/add`, newTask);
	}

	checkUniqueTaskName(
		taskName: string,
		userId: string,
		currentTaskId?: string
	): Observable<boolean> {
		if (currentTaskId) {
			return this.httpClient.get<boolean>(
				`${this.url}/unique?taskName=${taskName}&userId=${userId}&currentTaskId=${currentTaskId}`
			);
		} else {
			return this.httpClient.get<boolean>(
				`${this.url}/unique?taskName=${taskName}&userId=${userId}`
			);
		}
	}
}
