import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { UserSummary } from '../_interfaces/user-summary.interface';
import { UserDetails } from '../_interfaces/user-details.interface';
import { USER_URL } from '../_constants/endpoints.constants';

@Injectable({ providedIn: 'root' })
export class UserService {
  private url = USER_URL;
  private httpClient = inject(HttpClient);

  public getUsers(): Observable<UserSummary[]> {
    return this.httpClient.get<UserSummary[]>(this.url);
  }

  public getUserDetails(id: string): Observable<UserDetails> {
    return this.httpClient.get<UserDetails>(`${this.url}/by-id?id=${id}`);
  }
}
