import { Injectable, signal, computed } from '@angular/core';
import { Notification } from '../_interfaces/notification.interface';
import { NotificationType } from '../_enums/notification-type.enum';
import { Observable, Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class NotificationService {
	private notificationSubject = new Subject<Notification | null>();

	get notification$(): Observable<Notification | null> {
		return this.notificationSubject.asObservable();
	}

	notify(type: NotificationType, message: string): void {
		this.notificationSubject.next({ type, message });
	}
}
