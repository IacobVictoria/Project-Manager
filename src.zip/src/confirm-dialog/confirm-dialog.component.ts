import { Component, inject, Inject, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { ConfirmDialogData } from '../_interfaces/confirm-dialog-data.interface';

@Component({
	selector: 'app-confirm-dialog',
	standalone: true,
	imports: [MatDialogModule, MatIconModule, MatButtonModule],
	templateUrl: './confirm-dialog.component.html',
	styleUrl: './confirm-dialog.component.scss',
})
export class ConfirmDialogComponent {
	public data: ConfirmDialogData = inject<ConfirmDialogData>(MAT_DIALOG_DATA);
}
