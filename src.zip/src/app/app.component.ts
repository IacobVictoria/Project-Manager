import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { UserTasksPageComponent } from '../user-tasks-page/user-tasks-page.component';
import { LoadingSpinnerComponent } from '../_shared/loading-spinner/loading-spinner.component';
import { NotificationComponent } from "../notification/notification.component";

@Component({
	selector: 'app-root',
	standalone: true,
	imports: [
    CommonModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    RouterOutlet,
    HeaderComponent,
    FooterComponent,
    UserTasksPageComponent,
    LoadingSpinnerComponent,
    NotificationComponent
],
	templateUrl: './app.component.html',
	styleUrl: './app.component.scss',
})
export class AppComponent {
	title = 'task-manager';
}
