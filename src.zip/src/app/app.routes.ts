import { Routes } from '@angular/router';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { UserDetailsPageComponent } from '../user-details-page/user-details-page.component';
import { TaskPageComponent } from '../task-page/task-page.component';
import { UserTasksPageComponent } from '../user-tasks-page/user-tasks-page.component';
import { TaskResolver } from '../_resolvers/task.resolver';
import { showLeavePageConfirmationDialogGuard } from '../_guards/show-leave-page-confirmation-dialog.guard';

export const routes: Routes = [
	{ path: '', component: UserTasksPageComponent },
	{
		path: 'add-task',
		canDeactivate: [showLeavePageConfirmationDialogGuard],
		component: TaskPageComponent,
	},
	{ path: 'user-details/:id', component: UserDetailsPageComponent },
	{ path: 'user-tasks', component: UserTasksPageComponent },
	{
		path: 'edit-task/:id',
		component: TaskPageComponent,
		canDeactivate: [showLeavePageConfirmationDialogGuard],
		resolve: {
			task: TaskResolver,
		},
	},
	{ path: '**', component: PageNotFoundComponent },
];
