import {
	HTTP_INTERCEPTORS,
	provideHttpClient,
	withFetch,
	withInterceptors,
} from '@angular/common/http';
import {
	ApplicationConfig,
	provideZoneChangeDetection,
	importProvidersFrom,
	inject,
} from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { routes } from './app.routes';
import { notificationsInterceptor } from '../_interceptors/notifications.interceptor';
import { loadingInterceptor } from '../_interceptors/loading.interceptor';

export const appConfig: ApplicationConfig = {
	providers: [
		provideZoneChangeDetection({ eventCoalescing: true }),
		provideRouter(routes, withComponentInputBinding()),
		provideHttpClient(
			withFetch(),
			withInterceptors([notificationsInterceptor, loadingInterceptor])
		),
		importProvidersFrom(BrowserAnimationsModule),
		provideAnimationsAsync(),
	],
};
