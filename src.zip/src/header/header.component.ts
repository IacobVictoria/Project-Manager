import { Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { RefreshService } from '../_services/refresh.service';

@Component({
	selector: 'app-header',
	standalone: true,
	imports: [
		MatButtonModule,
		MatDividerModule,
		MatIconModule,
		CommonModule,
		RouterOutlet,
		RouterLink,
		RouterLinkActive,
		RouterOutlet,
	],
	templateUrl: './header.component.html',
	styleUrl: './header.component.scss',
})
export class HeaderComponent {
	refreshService: RefreshService = inject(RefreshService);

	onRefresh(): void {
		this.refreshService.triggerRefresh();
	}
}
