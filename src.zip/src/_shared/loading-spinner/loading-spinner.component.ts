import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { LoaderService } from '../../_services/loading.service';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';

@Component({
	selector: 'app-loading-spinner',
	standalone: true,
	imports: [CommonModule, MatProgressSpinnerModule],
	templateUrl: './loading-spinner.component.html',
	styleUrls: ['./loading-spinner.component.scss'],
})
export class LoadingSpinnerComponent implements OnInit, OnDestroy {
	isLoading: boolean = false;
	private subscription = new Subscription();

	constructor(private loaderService: LoaderService) {}

	ngOnInit(): void {
		this.subscription.add(
			this.loaderService.isLoading$.subscribe((isLoading) => {
				if (isLoading) {
					this.isLoading = true;
				} else {
					setTimeout(() => {
						this.isLoading = false;
					}, 350);
				}
			})
		);
	}

	ngOnDestroy(): void {
		this.subscription.unsubscribe();
	}
}
