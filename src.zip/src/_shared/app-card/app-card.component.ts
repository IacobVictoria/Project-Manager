import { CommonModule } from '@angular/common';
import { Component, Input, TemplateRef } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatCardModule } from '@angular/material/card';

@Component({
	selector: 'app-card',
	standalone: true,
	imports: [
		CommonModule,
		MatButtonModule,
		MatCardModule,
		MatDividerModule,
		MatExpansionModule,
		MatIconModule,
	],
	templateUrl: './app-card.component.html',
	styleUrls: ['./app-card.component.scss'],
})
export class AppCardComponent {
	@Input({ required: true }) title!: string;
  @Input() subtitle?: string;
}
