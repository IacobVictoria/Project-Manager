import { CommonModule } from '@angular/common';
import { Component, ContentChild, Input, TemplateRef } from '@angular/core';

@Component({
	selector: 'app-list-container',
	standalone: true,
	imports: [CommonModule],
	templateUrl: './list-container.component.html',
	styleUrl: './list-container.component.scss',
})
export class ListContainerComponent {
	@Input() items: unknown[] = [];
	@Input() trackByFn!: (index: number, item: any) => any;
	@ContentChild(TemplateRef) itemTemplate!: TemplateRef<any>;
}
