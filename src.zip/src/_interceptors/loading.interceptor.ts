import {
	HttpEventType,
	HttpHandlerFn,
	HttpInterceptorFn,
	HttpRequest,
} from '@angular/common/http';
import { finalize, tap } from 'rxjs/operators';
import { NotificationService } from '../_services/notification.service';
import { inject } from '@angular/core';
import { NotificationType } from '../_enums/notification-type.enum';
import { NOTIFICATION_HTTP_METHODS } from '../_constants/notification-http-methods.constants';
import { LoaderService } from '../_services/loading.service';

export const loadingInterceptor: HttpInterceptorFn = (
	req: HttpRequest<unknown>,
	next: HttpHandlerFn
) => {
	const loaderService = inject(LoaderService);

	loaderService.show();

	return next(req).pipe(finalize(() => loaderService.hide()));
};
