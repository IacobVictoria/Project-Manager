import {
	HttpEventType,
	HttpHandlerFn,
	HttpInterceptorFn,
	HttpRequest,
} from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { NotificationService } from '../_services/notification.service';
import { inject } from '@angular/core';
import { NotificationType } from '../_enums/notification-type.enum';
import { NOTIFICATION_HTTP_METHODS } from '../_constants/notification-http-methods.constants';

export const notificationsInterceptor: HttpInterceptorFn = (
	req: HttpRequest<unknown>,
	next: HttpHandlerFn
) => {
	if (!NOTIFICATION_HTTP_METHODS.includes(req.method)) {
		return next(req);
	}

	const notificationService = inject(NotificationService);
	return next(req).pipe(
		tap({
			next: (event) => {
				if (event.type === HttpEventType.Response) {
					if (event.status === 200) {
						notificationService.notify(
							NotificationType.Success,
							`${req.method} Request successful`
						);
					} else {
						notificationService.notify(
							NotificationType.Error,
							`${req.method} Request unsuccessful`
						);
					}
				}
			},
			error: (error) => {
				notificationService.notify(
					NotificationType.Error,
					`Error occurred : ${error.statusText} | Status: ${error.status}`
				);
			},
		})
	);
};
