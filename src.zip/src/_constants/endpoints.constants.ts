export const BASE_URL = 'https://localhost:7036/api';
export const TASK_URL = `${BASE_URL}/task`;
export const USER_URL = `${BASE_URL}/user`;
