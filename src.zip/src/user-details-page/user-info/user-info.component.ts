import { Component, inject, Input, OnInit } from '@angular/core';
import { UserDetails } from '../../_interfaces/user-details.interface';
import { UserService } from '../../_services/user.service';
import { DatePipe } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { AppCardComponent } from '../../_shared/app-card/app-card.component';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { RefreshService } from '../../_services/refresh.service';

@Component({
	selector: 'app-user-info',
	standalone: true,
	imports: [
		MatButtonModule,
		MatDividerModule,
		MatIconModule,
		MatExpansionModule,
		MatCardModule,
		AppCardComponent,
		DatePipe,
	],
	templateUrl: './user-info.component.html',
	styleUrl: './user-info.component.scss',
})
export class UserInfoComponent implements OnInit {
	private subscription: Subscription = new Subscription();
	private refreshService: RefreshService = inject(RefreshService);
	protected userId?: string;

	@Input('id')
	userDetails?: UserDetails;

	constructor(
		private route: ActivatedRoute,
		private userService: UserService
	) {}

	ngOnInit(): void {
		this.subscription.add(
			this.route.params.subscribe((params) => {
				this.userId = params['id'];

				if (!this.userId) return;

				this.loadUserDetails(this.userId);
			})
		);

		this.subscription.add(
			this.refreshService.refresh.subscribe(() => {
				if (this.userId) {
					this.loadUserDetails(this.userId);
				}
			})
		);
	}

	ngOnDestroy(): void {
		this.subscription.unsubscribe();
	}

	private loadUserDetails(userId: string): void {
		this.userService.getUserDetails(userId).subscribe({
			next: (data: UserDetails) => {
				this.userDetails = data;
			},
		});
	}
}
