import { Component } from '@angular/core';
import { UserInfoComponent } from "./user-info/user-info.component";
import { UserComponent } from "../user-tasks-page/user-list/user/user.component";
import { TasksTableComponent } from "./tasks-table/tasks-table.component";

@Component({
	selector: 'app-user-details-page',
	standalone: true,
	imports: [UserInfoComponent, UserComponent, TasksTableComponent],
	templateUrl: './user-details-page.component.html',
	styleUrls: ['./user-details-page.component.scss'],
})
export class UserDetailsPageComponent {}
