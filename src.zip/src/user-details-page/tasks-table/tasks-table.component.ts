import { Component, inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef, GridReadyEvent } from 'ag-grid-community';
import { TaskService } from '../../_services/task.service';
import { Task } from '../../_interfaces/task.interface';
import { ActivatedRoute } from '@angular/router';
import { TaskStatus } from '../../_enums/task-status.enum';
import { DatePipe } from '@angular/common';
import { Subscription, take } from 'rxjs';
import { RefreshService } from '../../_services/refresh.service';

@Component({
	selector: 'app-tasks-table',
	standalone: true,
	imports: [AgGridAngular],
	templateUrl: './tasks-table.component.html',
	styleUrl: './tasks-table.component.scss',
	providers: [DatePipe],
})
export class TasksTableComponent implements OnInit, OnDestroy {
	private refreshService: RefreshService = inject(RefreshService);
	private taskService: TaskService = inject(TaskService);
	datePipe: DatePipe = inject(DatePipe);
	private subscription: Subscription = new Subscription();

	userId!: string;

	@ViewChild(AgGridAngular) agGrid!: AgGridAngular;

	constructor(private route: ActivatedRoute) {}

	ngOnInit(): void {
		this.subscription.add(
			this.route.params.subscribe((params) => {
				this.userId = params['id'];
			})
		);

		this.subscription.add(
			this.refreshService.refresh.subscribe(() => {
				if (!this.userId) return;

				this.taskService
					.getTasks(this.userId)
					.pipe(take(1))
					.subscribe((data: Task[]) => {
						this.rowData = data;
					});

				if (!this.agGrid) return;

				this.onRefresh();
			})
		);
	}

	ngOnDestroy(): void {
		this.subscription.unsubscribe();
	}

	defaultColDef: ColDef = {
		filter: true,
	};

	rowData: Task[] = [];
	colDefs: ColDef[] = [
		{ field: 'title', headerName: 'Title', sort: 'asc' },
		{ field: 'description', headerName: 'Description' },
		{
			field: 'status',
			headerName: 'Status',
			valueFormatter: (params) => TaskStatus[params.value],
		},
		{
			field: 'dueDate',
			headerName: 'Due Date',
			valueFormatter: (params) =>
				this.datePipe.transform(params.value, 'medium') || '',
		},
		{
			field: 'startedAt',
			headerName: 'Started At',
			sort: 'desc',
			valueFormatter: (params) =>
				this.datePipe.transform(params.value, 'medium') || '',
		},
		{
			field: 'completedAt',
			headerName: 'Completed At',
			valueFormatter: (params) =>
				this.datePipe.transform(params.value, 'medium') || '',
		},
	];

	onGridReady(params: GridReadyEvent): void {
		this.taskService.getTasks(this.userId).subscribe((data: Task[]) => {
			this.rowData = data;
		});
	}

	onRefresh(): void {
		this.agGrid.api.refreshCells();
		this.agGrid.api.setFilterModel(null);
	}
}
