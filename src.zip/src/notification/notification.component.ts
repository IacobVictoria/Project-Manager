import {
	Component,
	computed,
	effect,
	OnDestroy,
	OnInit,
	signal,
	ViewEncapsulation,
} from '@angular/core';
import { NotificationService } from '../_services/notification.service';
import { Notification } from '../_interfaces/notification.interface';
import { CommonModule } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Subscription } from 'rxjs';

@Component({
	selector: 'app-notification',
	standalone: true,
	imports: [CommonModule],
	templateUrl: './notification.component.html',
	styleUrl: './notification.component.scss',
	encapsulation: ViewEncapsulation.None,
})
export class NotificationComponent implements OnInit, OnDestroy {
	notification: Notification | null = null;
	notificationSubscription: Subscription | undefined;

	constructor(
		private notificationService: NotificationService,
		private snackBar: MatSnackBar
	) {}

	ngOnInit(): void {
		this.notificationSubscription =
			this.notificationService.notification$.subscribe((notification) => {
				this.notification = notification;
				if (this.notification) {
					this.showSnackBar(this.notification);
				}
			});
	}

	ngOnDestroy(): void {
		if (this.notificationSubscription) {
			this.notificationSubscription.unsubscribe();
		}
	}

	showSnackBar(notification: Notification): void {
		this.snackBar.open(notification.message, 'Close', {
			duration: 2000,
			panelClass: ['custom-snackbar', notification.type],
		});
	}
}
