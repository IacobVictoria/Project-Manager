import { Component, inject, Input, OnInit, OnDestroy } from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
	ReactiveFormsModule,
	Validators,
} from '@angular/forms';
import { TaskForm } from '../_interfaces/task-form.interface';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
import { TaskService } from '../_services/task.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Task } from '../_interfaces/task.interface';
import { uniqueTaskNameValidator } from '../task-validator/unique-task-validator';
import { CommonModule } from '@angular/common';
import { TaskStatus } from '../_enums/task-status.enum';
import { AddTaskRequest } from '../_interfaces/add-task-request.interface';
import { UpdateTaskRequest } from '../_interfaces/update-task-request.interface';
import { UserSummary } from '../_interfaces/user-summary.interface';
import { ConfirmDialogService } from '../_services/confirm-dialog.service';
import { UserService } from '../_services/user.service';
import { TaskStatusUtils } from '../_utils/task-status.utils';
import { Subscription, take } from 'rxjs';
import { SelectItem } from '../_interfaces/select-item.interface';
import { ShowLeavePageConfirmationDialog } from '../_interfaces/show-leave-confirmation-dialog.interface';

@Component({
	selector: 'app-task-page',
	standalone: true,
	providers: [provideNativeDateAdapter()],
	imports: [
		ReactiveFormsModule,
		MatFormFieldModule,
		MatInputModule,
		MatButtonModule,
		MatIconModule,
		MatSelectModule,
		MatDatepickerModule,
		CommonModule,
	],
	templateUrl: './task-page.component.html',
	styleUrl: './task-page.component.scss',
})
export class TaskPageComponent implements OnInit, OnDestroy, ShowLeavePageConfirmationDialog {
	private subscription = new Subscription();
	private taskService = inject(TaskService);
	private userService = inject(UserService);
	private activatedRoute = inject(ActivatedRoute);
	taskStatusOptions: SelectItem[] = [];
	users: UserSummary[] = [];
	formGroup!: FormGroup<TaskForm>;
	private isSubmitting = false;

	@Input('id')
	protected taskId?: string;

	constructor(
		private formBuilder: FormBuilder,
		private router: Router,
		private dialogService: ConfirmDialogService
	) {}

	ngOnInit(): void {
		this.subscription.add(
			this.userService.getUsers().subscribe((users) => {
				this.users = users;
			})
		);
		this.taskStatusOptions = TaskStatusUtils.mapTaskStatusToSelectOption();
		this.activatedRoute.data.subscribe(({ task }) => {
			this.createForm(task);
		});
	}

	ngOnDestroy(): void {
		this.subscription.unsubscribe();
	}

	createForm(task?: Task): void {
		this.formGroup = this.formBuilder.group<TaskForm>({
			userId: new FormControl<string>(
				{ value: task ? task.userId : '', disabled: !!task },
				[Validators.required]
			),
			title: new FormControl(task ? task.title : '', [
				Validators.required,
				Validators.minLength(3),
			]),
			description: new FormControl(task ? task.description : '', [
				Validators.required,
			]),
			status: new FormControl(task ? task.status : TaskStatus.Active, [
				Validators.required,
			]),
			dueDate: new FormControl(
				{ value: task ? task.dueDate : null, disabled: !!task },
				[Validators.required]
			),
			startedAt: new FormControl({
				value: task ? task.startedAt : null,
				disabled: !!task,
			}),
			completedAt: new FormControl(task ? task.completedAt : null),
		});

		this.formGroup
			.get('title')
			?.setAsyncValidators(
				uniqueTaskNameValidator(
					this.taskService,
					this.formGroup.get('userId'),
					this.taskId
				)
			);

		this.formGroup.get('userId')?.valueChanges.subscribe((value) => {
			this.formGroup.get('title')?.updateValueAndValidity();
		});
	}

	submit(): void {
		this.isSubmitting = true;
		this.formGroup.markAsPristine();

		if (this.taskId) {
			this.editTask();
		} else {
			this.addTask();
		}
	}

	editTask(): void {
		const newTask: UpdateTaskRequest = {
			status: this.formGroup.value.status!,
			description: this.formGroup.value.description!,
			completedAt: this.formGroup.value.completedAt,
			id: this.taskId!,
		};

		this.taskService
			.editTask(newTask)
			.pipe(take(1))
			.subscribe(() => {
				this.isSubmitting = false;
				this.router.navigate(['/user-tasks']);
			}, () => {
				this.isSubmitting = false;
			});
	}

	addTask(): void {
		const newTask: AddTaskRequest = {
			status: this.formGroup.value.status!,
			description: this.formGroup.value.description!,
			completedAt: this.formGroup.value.completedAt,
			title: this.formGroup.value.title!,
			userId: this.formGroup.value.userId!,
			startedAt: this.formGroup.value.startedAt!,
			dueDate: this.formGroup.value.dueDate!,
		};

		this.taskService
			.addNewTask(newTask)
			.pipe(take(1))
			.subscribe(() => {
				this.isSubmitting = false;
				this.router.navigate(['/user-tasks']);
			}, () => {
				this.isSubmitting = false;
			});
	}

	showLeavePageConfirmationDialog(): boolean {
		return this.formGroup.dirty && !this.isSubmitting;
	}

	cancel(): void {
		if (this.formGroup.dirty) {
			this.dialogService
				.confirmDialog({
					title: 'Confirm Cancel',
					message: 'Are you sure you want to cancel? Any unsaved changes will be lost.',
					confirmText: 'Yes, Cancel',
					cancelText: 'No, Go Back',
				})
				.subscribe((result) => {
					if (result) {
						this.router.navigate(['/user-tasks']);
					}
				});
		} else {
			this.router.navigate(['/user-tasks']);
		}
	}
}
