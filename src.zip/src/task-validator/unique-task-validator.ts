import {
	AbstractControl,
	ValidationErrors,
	AsyncValidatorFn,
} from '@angular/forms';
import { Observable, of, timer } from 'rxjs';
import {
	catchError,
	debounce,
	debounceTime,
	map,
	switchMap,
} from 'rxjs/operators';
import { TaskService } from '../_services/task.service';

export function uniqueTaskNameValidator(
	taskValidationService: TaskService,
	dependentControl?: AbstractControl | null,
	currentTaskId?: string
): AsyncValidatorFn {
	return (
		control: AbstractControl | null
	): Observable<ValidationErrors | null> => {
		if (!control?.value || !dependentControl?.value) {
			return of(null);
		}

		return timer(700).pipe(
			switchMap(() => {
				return taskValidationService
					.checkUniqueTaskName(
						control.value,
						dependentControl.value,
						currentTaskId
					)
					.pipe(
						map((isUnique) =>
							isUnique ? null : { nonUniqueTaskName: true }
						),
						catchError(() => of(null))
					);
			})
		);
	};
}
