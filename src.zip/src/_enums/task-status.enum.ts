export enum TaskStatus {
    Started = 0,
    Active = 1,
    Completed = 2
}