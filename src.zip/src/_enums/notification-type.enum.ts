export enum NotificationType {
	Success = 'success',
	Error = 'error',
}
